#!/bin/bash
# Verifier entrypoint (shared frame; synced by tools/sync_verifier.py).
# Patching and grading live in tests/grader.py. This script owns the
# task-specific part: run the suites, write reports under /logs/verifier/,
# and apply any report fixups before grading.
set -uo pipefail
trap 'if [ ! -f /logs/verifier/reward.json ] && [ ! -f /logs/verifier/reward.txt ]; then mkdir -p /logs/verifier; echo -1 > /logs/verifier/reward.txt; fi' EXIT
log() { echo "[verifier] $*"; }
cd /app || { mkdir -p /logs/verifier; exit 6; }

python3 /tests/grader.py prepare || exit $?
[ -f /logs/verifier/reward.json ] && exit 0   # model.patch didn't apply -> graded 0

# Canonical raw-output log. The task middle SHOULD send every suite's combined
# stdout+stderr here so the reason a test failed is never lost -- use run_log,
# or pipe through `tee -a "$RUN_LOG"` when feeding a reporter. Never 2>/dev/null
# a test run. FRAME_SUFFIX cats this (and any other raw logs) into test-stdout.
export RUN_LOG=/logs/verifier/run.log
: > "$RUN_LOG" 2>/dev/null || true
run_log() { echo "+ $*" >> "$RUN_LOG" 2>/dev/null; "$@" 2>&1 | tee -a "$RUN_LOG"; return "${PIPESTATUS[0]}"; }

# >>> RUN TESTS (task-specific) <<<
# (v1.1 migration, from the old header:)
# differential and shipped as /tests/config.json in the CTRF name
# format of junit-to-ctrf (official ctrf-io converter) over vitest's built-in
# JUnit reporter. Missing-from-report counts as failed.
# (scan-config rationale:)
# Cheating signal (recorded only): package manifest, npm lockfile, node_modules, .npmrc,
# or a vite config (test-runner hijack). The golden never touches these.
# NOT hard: vitest.config.ts (the golden solution itself edits its exclude
# list) and vitest.new.config.ts (owned by test.patch: reset + reapplied below,
# so model edits to it are moot). Whitelist missing=failed semantics neutralize
# include-glob tampering in vitest.config.ts.
# Out-of-scope signal (recorded only): paths outside the task's expected fix scope (src/**,
# vitest.config.ts).

require_cmd() { command -v "$1" >/dev/null 2>&1 || { log "ERROR: missing $1; PATH=$PATH"; exit 127; }; }
require_cmd node; require_cmd npx; require_cmd junit-to-ctrf

# --- Run base/new with reporter (mode_command_adapter: /app/test.sh hardcodes
# `--reporter=verbose`; same commands/configs with the built-in junit reporter
# swapped in — file selection lives in the configs, not CLI args; the original
# modes have no fail-fast flags to strip) ---
set +e
npx vitest run --reporter=junit --outputFile=/logs/verifier/base.xml \
    --config vitest.config.ts > /logs/verifier/base_run.log 2>&1
NODE_OPTIONS='--require tsx/cjs --import tsx/esm' \
npx vitest run --reporter=junit --outputFile=/logs/verifier/new.xml \
    --config vitest.new.config.ts > /logs/verifier/new_run.log 2>&1
set -e

# --- Convert each mode's JUnit XML to CTRF with the OFFICIAL ctrf-io
# converter (junit-to-ctrf@0.0.14, pinned in the image). --use-suite-name is
# load-bearing: it prefixes the file path so names can't collide across files.
# junit-to-ctrf exits 0 even on errors, so the output is verified to exist and
# be valid JSON; a missing/invalid CTRF is removed so the grader scores every
# whitelisted id of that mode as failed (missing-from-report) — never a crash.
convert_junit() { # $1 = junit xml, $2 = ctrf json out
  rm -f "$2"
  if ! junit-to-ctrf "$1" -o "$2" -t vitest --use-suite-name \
      >> /logs/verifier/ctrf_convert.log 2>&1; then
    log "WARNING: junit-to-ctrf exited nonzero for $1"
  fi
  if [ ! -s "$2" ] || ! python3 -c 'import json,sys; json.load(open(sys.argv[1]))' "$2" >/dev/null 2>&1; then
    log "WARNING: missing/invalid CTRF at $2 — its whitelisted ids will count as failed"
    rm -f "$2"
  fi
}
convert_junit /logs/verifier/base.xml /logs/verifier/base-ctrf.json
convert_junit /logs/verifier/new.xml  /logs/verifier/new-ctrf.json

# >>> REPORT FIXUP <<<
# vitest<2 renders never-run tests as junit passes when a suite hook fails; the sentinel
# '<file>: <file>' testcase carries the failure; this fails the whole file's tests (was grader option hook_propagation).
propagate_hook_failure() { # $1 = ctrf json, edited in place
  [ -s "$1" ] || return 0
  python3 - "$1" <<'PY'
import json, sys
p = sys.argv[1]; doc = json.load(open(p))
tests = (doc.get("results") or {}).get("tests") or []
def cls(t):
    su = t.get("suite")
    su = str(su[0]).strip() if isinstance(su, list) and su else (su.strip() if isinstance(su, str) else "")
    nm = str(t.get("name") or "").strip()
    return su or (nm.split(": ", 1)[0] if ": " in nm else "")
def is_failed(t):  # mirror grader norm_status: unknown -> failed
    return str(t.get("status") or "").strip().lower() not in ("passed", "skipped", "pending", "other")
bad = {cls(t) for t in tests if isinstance(t, dict) and is_failed(t) and cls(t)
       and str(t.get("name") or "").strip() == f"{cls(t)}: {cls(t)}"}
for t in tests:
    if isinstance(t, dict) and cls(t) in bad:
        t["status"] = "failed"
if bad: json.dump(doc, open(p, "w"))
PY
}
propagate_hook_failure /logs/verifier/base-ctrf.json
propagate_hook_failure /logs/verifier/new-ctrf.json
# >>> END REPORT FIXUP <<<
# >>> END RUN TESTS <<<

# Surface raw suite output into our stdout (the harness captures it into
# test-stdout.txt) so failures are debuggable even when the framework report
# omits the reason (e.g. cargo-nextest). Reasons-per-test come from grade below.
_seen=""
for _rl in "$RUN_LOG" /logs/verifier/*_run.log /logs/verifier/*-run.log /logs/verifier/*-mocha.log /logs/verifier/*.log /logs/verifier/*.out; do
  [ -f "$_rl" ] && [ -s "$_rl" ] || continue
  case " $_seen " in *" $_rl "*) continue ;; esac
  case "${_rl##*/}" in *convert*.log|ctrf*.log|junit*.log) continue ;; esac
  _seen="$_seen $_rl"
  echo "===== raw suite output: ${_rl##*/} ====="
  cat "$_rl"
done 2>/dev/null
echo "===== grade ====="

python3 /tests/grader.py grade
log "reward.json=$(cat /logs/verifier/reward.json 2>/dev/null)"

# Uniform top level: keep only the canonical artifacts at /logs/verifier and
# tuck every framework-native report/log under reports/ (full provenance, no
# data dropped -- just moved). Canonical: reward.json, ctrf.json, run.log, and
# the harness-written test-stdout.txt.
mkdir -p /logs/verifier/reports 2>/dev/null
for _f in /logs/verifier/*; do
  case "${_f##*/}" in
    reward.json|reward.txt|ctrf.json|run.log|test-stdout.txt|reports) continue ;;
  esac
  [ -f "$_f" ] && mv -f "$_f" /logs/verifier/reports/ 2>/dev/null
done
