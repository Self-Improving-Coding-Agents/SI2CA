#!/bin/bash
# Verifier entrypoint (shared frame; synced by tools/sync_verifier.py).
# Patching and grading live in tests/grader.py. This script owns the
# task-specific part: run the suites, write reports under /logs/verifier/,
# and apply any report fixups before grading.
set -uo pipefail
trap 'if [ ! -f /logs/verifier/reward.json ] && [ ! -f /logs/verifier/reward.txt ]; then mkdir -p /logs/verifier; echo -1 > /logs/verifier/reward.txt; fi' EXIT
log() { echo "[verifier] $*"; }
cd /app || { mkdir -p /logs/verifier; exit 6; }

python3 /tests/grader.py prepare || exit $?
[ -f /logs/verifier/reward.json ] && exit 0   # model.patch didn't apply -> graded 0

# Canonical raw-output log. The task middle SHOULD send every suite's combined
# stdout+stderr here so the reason a test failed is never lost -- use run_log,
# or pipe through `tee -a "$RUN_LOG"` when feeding a reporter. Never 2>/dev/null
# a test run. FRAME_SUFFIX cats this (and any other raw logs) into test-stdout.
export RUN_LOG=/logs/verifier/run.log
: > "$RUN_LOG" 2>/dev/null || true
run_log() { echo "+ $*" >> "$RUN_LOG" 2>/dev/null; "$@" 2>&1 | tee -a "$RUN_LOG"; return "${PIPESTATUS[0]}"; }

# >>> RUN TESTS (task-specific) <<<
# (v1.1 migration, from the old header:)
# differential and read from /tests/config.json in CTRF name format
# "<file path>: <describe chain> > <title>". Missing-from-report counts as failed.
# (scan-config rationale:)
# Cheating signal (recorded only): package manifests/lockfiles, pnpm workspace config,
# vitest/vite runner config, or vendored node_modules. The golden never touches these.
# Out-of-scope signal (recorded only): paths outside the task's expected fix scope (packages/core/src/**).

require_cmd() { command -v "$1" >/dev/null 2>&1 || { log "ERROR: missing $1; PATH=$PATH"; exit 127; }; }
require_cmd pnpm; require_cmd node; require_cmd junit-to-ctrf

# --- Run base/new with reporter (mode_command_adapter: the inner /app/test.sh
# hardcodes its pnpm commands without arg passthrough, so we run the same
# commands directly with vitest's built-in junit reporter appended; the base
# mode's two package invocations are split so a core failure cannot mask the
# react suite, and each writes its own XML, merged into one CTRF per mode) ---
set +e
pnpm -F core test run --exclude='**/aspect.test.ts' --reporter=junit --outputFile=/logs/verifier/base.xml
pnpm -F react test run --reporter=junit --outputFile=/logs/verifier/base2.xml
pnpm -F core test run tests/aspect.test.ts --reporter=junit --outputFile=/logs/verifier/new.xml

# --- Convert each mode's JUnit XML(s) to CTRF with the OFFICIAL converter ---
# junit-to-ctrf@0.0.14 (ctrf-io). The glob is quoted so the converter (not the
# shell) expands it and merges base.xml+base2.xml into one CTRF report.
# --use-suite-name is load-bearing: it prefixes names with the suite (file
# path), avoiding cross-file title collisions. NOTE: junit-to-ctrf can exit 0
# even on errors, so the grader treats a missing/invalid CTRF as "all of that
# mode's whitelisted ids failed" — never a crash.
junit-to-ctrf '/logs/verifier/base*.xml' -o /logs/verifier/base-ctrf.json -t vitest --use-suite-name
junit-to-ctrf '/logs/verifier/new.xml' -o /logs/verifier/new-ctrf.json -t vitest --use-suite-name
for f in /logs/verifier/base-ctrf.json /logs/verifier/new-ctrf.json; do
  if python3 -c 'import json,sys; json.load(open(sys.argv[1]))' "$f" 2>/dev/null; then
    log "CTRF ok: $f"
  else
    log "WARNING: $f missing or invalid JSON — that mode's whitelisted ids will grade as failed"
  fi
done
set -e
# >>> END RUN TESTS <<<

# Surface raw suite output into our stdout (the harness captures it into
# test-stdout.txt) so failures are debuggable even when the framework report
# omits the reason (e.g. cargo-nextest). Reasons-per-test come from grade below.
_seen=""
for _rl in "$RUN_LOG" /logs/verifier/*_run.log /logs/verifier/*-run.log /logs/verifier/*-mocha.log /logs/verifier/*.log /logs/verifier/*.out; do
  [ -f "$_rl" ] && [ -s "$_rl" ] || continue
  case " $_seen " in *" $_rl "*) continue ;; esac
  case "${_rl##*/}" in *convert*.log|ctrf*.log|junit*.log) continue ;; esac
  _seen="$_seen $_rl"
  echo "===== raw suite output: ${_rl##*/} ====="
  cat "$_rl"
done 2>/dev/null
echo "===== grade ====="

python3 /tests/grader.py grade
log "reward.json=$(cat /logs/verifier/reward.json 2>/dev/null)"

# Uniform top level: keep only the canonical artifacts at /logs/verifier and
# tuck every framework-native report/log under reports/ (full provenance, no
# data dropped -- just moved). Canonical: reward.json, ctrf.json, run.log, and
# the harness-written test-stdout.txt.
mkdir -p /logs/verifier/reports 2>/dev/null
for _f in /logs/verifier/*; do
  case "${_f##*/}" in
    reward.json|reward.txt|ctrf.json|run.log|test-stdout.txt|reports) continue ;;
  esac
  [ -f "$_f" ] && mv -f "$_f" /logs/verifier/reports/ 2>/dev/null
done
